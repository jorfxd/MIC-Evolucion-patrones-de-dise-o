class ProfessionalEntity {
  final String id;
  final String name;

  ProfessionalEntity({required this.id, required this.name});
}
