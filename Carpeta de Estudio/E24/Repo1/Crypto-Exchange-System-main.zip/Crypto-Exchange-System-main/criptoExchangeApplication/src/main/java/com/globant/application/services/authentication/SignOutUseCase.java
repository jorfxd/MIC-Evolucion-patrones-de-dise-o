package com.globant.application.services.authentication;

/**
 *
 * @author erillope
 */
public interface SignOutUseCase {
    public void signOut();
}
