package com.globant.domain.exchange;

/**
 *
 * @author erillope
 */
public enum TransactionType {
    BUY, SELL
}
