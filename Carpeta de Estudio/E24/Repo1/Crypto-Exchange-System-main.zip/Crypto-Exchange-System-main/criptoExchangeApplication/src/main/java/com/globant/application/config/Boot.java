package com.globant.application.config;

/**
 *
 * @author user
 */
public interface Boot {
    public void boot();
}
