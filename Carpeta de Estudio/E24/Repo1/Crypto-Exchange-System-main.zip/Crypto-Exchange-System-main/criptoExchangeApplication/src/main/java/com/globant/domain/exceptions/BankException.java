package com.globant.domain.exceptions;

/**
 *
 * @author erillope
 */
public class BankException extends DomainException{
    public BankException(String msg) {
        super(msg);
    }
}
