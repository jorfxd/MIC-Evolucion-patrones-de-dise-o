package com.globant.application.repositories.exceptions;

/**
 *
 * @author erillope
 */
public class KeyNotFoundException extends RepositoryException{
    public KeyNotFoundException(String msg) {
        super(msg);
    }
}
