package com.globant.domain.crypto;

/**
 *
 * @author erillope
 */
public enum CryptoCurrencyName {
    BITCOIN, ETHEREUM, RIPPLE;
}
