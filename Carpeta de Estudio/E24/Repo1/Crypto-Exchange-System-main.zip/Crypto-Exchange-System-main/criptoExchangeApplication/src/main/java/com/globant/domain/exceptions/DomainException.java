package com.globant.domain.exceptions;

/**
 *
 * @author erillope
 */
public class DomainException extends Exception{
    public DomainException(String msg) {
        super(msg);
    }
}
