package com.globant.domain.user.accounts;

/**
 *
 * @author erillope
 */
public enum BankName {
    PACIFICO, PICHINCHA
}
