local i = 1
while i <= 5 do
    print("Contador: " .. i)
    i = i + 1
end