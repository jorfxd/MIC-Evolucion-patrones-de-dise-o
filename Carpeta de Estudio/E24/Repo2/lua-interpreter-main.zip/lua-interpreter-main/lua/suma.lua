local suma = 0
local numeros = {5,6,7}
for n in numeros do suma = suma + n end