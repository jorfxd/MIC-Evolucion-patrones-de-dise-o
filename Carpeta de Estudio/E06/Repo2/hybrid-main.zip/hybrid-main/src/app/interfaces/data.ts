export interface Data {
    texto: string;
}