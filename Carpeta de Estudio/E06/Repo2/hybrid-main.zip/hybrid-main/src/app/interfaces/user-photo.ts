export interface UserPhoto {
    filepath: string;
    webviewPath?: string;
}
