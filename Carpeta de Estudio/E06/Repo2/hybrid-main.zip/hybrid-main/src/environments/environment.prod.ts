export const environment = {
  production: true,

  firebaseConfig: {
    apiKey: "AIzaSyA8S-c6AD4wDdN7YFtHqo1sJ_Nqs30keFo",
  authDomain: "hybrid-c961d.firebaseapp.com",
  databaseURL: "https://hybrid-c961d-default-rtdb.firebaseio.com",
  projectId: "hybrid-c961d",
  storageBucket: "hybrid-c961d.appspot.com",
  messagingSenderId: "7908334750",
  appId: "1:7908334750:web:8e7323f87f59817eabef8f"
}
};
