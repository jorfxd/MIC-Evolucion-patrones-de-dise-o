
package com.mycompany.proyectomd;

public class GUIStarter {


    public static void main(String[] args) {
        App.main(args);
    }
    
}
