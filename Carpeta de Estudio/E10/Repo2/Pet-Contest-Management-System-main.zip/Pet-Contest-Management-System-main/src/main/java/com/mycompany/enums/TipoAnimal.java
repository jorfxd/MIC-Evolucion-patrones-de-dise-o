package com.mycompany.enums;

//Enum para el tipo de mascota
public enum TipoAnimal {
    PERRO, GATO
}
