package com.mycompany.enums;

//Enum para el tipo de mascota de la que sera el concurso
public enum TipoAnimalesConcurso {
    PERROS, GATOS, TODOS  
}
