package com.group;

public enum TypeMember {
    BASIC,
    FAMILY,
    PREMIUM,
}
