
package ec.edu.espol.proyectopoo;

public enum TipoVehiculo {
    AUTO, CAMIONETA, MOTO;
}