/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

/**
 *
 * @author adan
 */
final class Constantes {
    
    private Constantes(){
         throw new IllegalStateException("Constantes class");
    }
    public static final int ANCHO = 1350;
    

    public static final int ALTO = 775;
    
}
