package com.brtsgn;

public abstract class Assortment {
    public abstract String getName();
    public abstract double getPrice();
    public abstract String getColor();
    public abstract int getStockNum();
    public abstract void setStockNum(int stockNum);
    public abstract void showFeatures();
}
