package com.brtsgn;

public class Camera extends Product {
    public Camera(String name, double price, String color, int stockNum) {
        super(name, price, color, stockNum);
        // System.out.println("CAMERA!!!");
    }
}
