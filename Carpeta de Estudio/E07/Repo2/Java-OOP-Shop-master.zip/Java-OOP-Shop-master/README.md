# Java-OOP-Shop
Java OOP Electronic Store with a Shopping Cart

ShopBS
Made by Mehmet Beraat Sagin for Advanced Proggramming Techniques lecture in University of Lodz,Poland
Simple Java application that includes an electronic store.

Inside of the store, there are a few products that you can add to your shopping cart. You can change the number of products or discard them.
If you have done then you can finish your shopping and get a reciept for your shopping.

I used mostly Object Oriented Programming techniques like Encapsulation, Inheritance, Polymorphism etc. That is why i choosed Java.
For production of every product there is a factory. I have used Factory Design Pattern for this purpose.
And there is Singleton Design Pattern for the shopping cart. 
