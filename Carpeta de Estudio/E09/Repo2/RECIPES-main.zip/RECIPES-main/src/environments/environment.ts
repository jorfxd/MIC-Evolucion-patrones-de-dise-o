
// src/environments/environment.ts
export const environment = {
  production: false,
  apiUrl: 'https://api.edamam.com/api/recipes/v2',
  apiId: '074535cb',
  apiKey: 'd680609f3d8ee94a78c255b90accb69b'
};