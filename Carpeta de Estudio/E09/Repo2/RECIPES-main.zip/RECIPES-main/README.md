# RECIPESAPI

Proyecto de ingreso a Kokoa

Se utiliza Ionic 7 y Angular 18

# API seleccionada

https://developer.edamam.com/recipe-demo

