# PokeAPI_DAWM
Ejemplo de uso de fetch con la API de Pokemon.
