# pagina_web-food_store-html-css-js

Página web desarrollada con su funcionalidad de parte del front-end (sin backend). Representa la página inicial de un restaurant de comida rápida.
Las tecnologías que se usaron principalmente fue:
* HTML
* CSS
* JavaScript

Además, se uso:

* SwiperJS: paquete usado para crear un carrusel que muestre los productos dentro de un loop infinito
* FlexBox: para crear una web responsive
