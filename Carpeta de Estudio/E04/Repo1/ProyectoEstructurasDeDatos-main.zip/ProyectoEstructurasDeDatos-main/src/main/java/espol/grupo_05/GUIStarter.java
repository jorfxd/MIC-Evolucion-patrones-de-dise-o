/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package espol.grupo_05;

/**
 *
 * @author quint
 */
public class GUIStarter {
    
        public static void main(final String[] args) {
        App.main(args);
    }

    
}
