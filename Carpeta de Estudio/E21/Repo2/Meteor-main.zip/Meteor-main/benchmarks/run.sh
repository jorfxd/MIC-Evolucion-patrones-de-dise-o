cd target/
java -jar benchmarks.jar -rf json