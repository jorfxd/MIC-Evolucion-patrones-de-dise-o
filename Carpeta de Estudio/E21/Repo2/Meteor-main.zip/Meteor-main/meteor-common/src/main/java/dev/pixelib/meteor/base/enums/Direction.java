package dev.pixelib.meteor.base.enums;

public enum Direction {

    METHOD_PROXY, // the side where the method was invoked
    IMPLEMENTATION // the side that holds the implementation of the method

}
