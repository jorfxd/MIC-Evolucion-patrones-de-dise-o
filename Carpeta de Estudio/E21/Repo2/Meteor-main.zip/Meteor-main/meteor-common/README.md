# meteor-base
## Description
This module does/should only contain bare minimum to get the meteor module working, and providing base interfaces or implementations for future extensions to be built upon (such as different transport protocols, etc.).