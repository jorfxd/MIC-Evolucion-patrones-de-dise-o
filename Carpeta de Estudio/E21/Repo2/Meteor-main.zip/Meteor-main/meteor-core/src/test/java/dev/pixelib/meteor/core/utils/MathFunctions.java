package dev.pixelib.meteor.core.utils;

public interface MathFunctions {

    int multiply(int x, int times);
    int add(int... numbers);
    int substract(int from, int... numbers);
}
