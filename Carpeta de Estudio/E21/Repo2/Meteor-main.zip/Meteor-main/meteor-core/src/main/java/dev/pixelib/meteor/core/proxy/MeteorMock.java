package dev.pixelib.meteor.core.proxy;

public interface MeteorMock {

    /*
     * This interface is treated as a marker interface to identify proxies from meteor.
     */

}
