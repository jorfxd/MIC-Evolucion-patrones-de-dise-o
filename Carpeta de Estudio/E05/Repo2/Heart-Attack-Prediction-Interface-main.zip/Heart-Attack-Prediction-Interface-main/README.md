# Heart-Attack-Prediction-Interface

Pasos para correr el programa en modo de desarrollo

En la terminal:

  -Instalar dependencias con "npm install"

  -Correr app con "npm start"
