# Proyecto Estructuras de Datos
En este proyecto, se implementará una aplicación gráfica de JavaFX que permitirá construir emojis de manera interactiva, a partir de imágenes que se utilizarán para componer los emojis. En gran parte, la funcionalidad que se solicita está inspirada en aplicaciones como Fluent Emoji Maker (https://fluent-emoji.ddiu.io)
