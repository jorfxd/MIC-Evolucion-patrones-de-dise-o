Proyecto 2 - Estructuras de datos - Grupo 10
Uso de árboles para generar una variación del juego de las 20 preguntas.
