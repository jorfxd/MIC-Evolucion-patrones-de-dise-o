/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EDD_2.models;

/**
 *
 * @author David
 */
public class Partida {
    
    private Player playerX;
    private Player playerCicle;
    private boolean isXTurn;
    private Board CurrentTablero;  
    
    
}
