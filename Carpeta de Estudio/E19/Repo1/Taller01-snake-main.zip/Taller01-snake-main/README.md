# Taller01-snake
conflicto 1
<span>![</span><span>imagen</span><span>]</span><span>(</span><span>https://raw.githubusercontent.com/Ariel-Vargas/Taller01-snake/main/error%20urgiles.png</span><span>)</span>
