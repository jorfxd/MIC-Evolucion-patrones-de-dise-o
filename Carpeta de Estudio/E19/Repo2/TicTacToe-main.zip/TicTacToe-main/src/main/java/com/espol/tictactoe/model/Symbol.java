
package com.espol.tictactoe.model;


public enum Symbol {
    X, O, EMPTY;
}
