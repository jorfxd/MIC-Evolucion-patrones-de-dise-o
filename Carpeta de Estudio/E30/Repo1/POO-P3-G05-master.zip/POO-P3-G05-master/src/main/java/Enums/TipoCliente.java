package Enums;


public enum TipoCliente {
    Personal,Empresarial
}
