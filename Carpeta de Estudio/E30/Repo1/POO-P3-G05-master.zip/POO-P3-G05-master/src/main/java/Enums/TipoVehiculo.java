package Enums;
//enum para los 3 tipos de vehiculo que se usan al crear una orden
public enum TipoVehiculo {Automovil, Motocicleta, Bus}

