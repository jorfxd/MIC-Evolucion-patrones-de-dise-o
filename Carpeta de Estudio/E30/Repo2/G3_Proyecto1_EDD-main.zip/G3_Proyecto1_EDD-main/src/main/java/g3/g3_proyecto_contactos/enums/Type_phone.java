/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package g3.g3_proyecto_contactos.enums;

/**
 *
 * @author oweny
 */
public enum Type_phone {
    WORK, HOME, MOBILE
}
