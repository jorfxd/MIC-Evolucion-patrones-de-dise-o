package Strategy;

public interface TransporteStrategy {
    
    public void distribuir();     
    
}
