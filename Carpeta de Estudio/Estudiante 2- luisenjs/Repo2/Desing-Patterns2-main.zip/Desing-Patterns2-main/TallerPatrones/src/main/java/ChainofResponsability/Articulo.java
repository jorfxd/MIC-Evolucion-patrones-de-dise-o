package ChainofResponsability;

public class Articulo {
    
}
