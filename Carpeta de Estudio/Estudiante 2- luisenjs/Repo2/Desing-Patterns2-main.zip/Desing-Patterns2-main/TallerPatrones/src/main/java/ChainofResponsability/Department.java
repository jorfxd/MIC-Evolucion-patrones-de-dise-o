package ChainofResponsability;

public interface Department {

    public void setNext(Department d);
    public void consultar(Articulo a);
    
}
