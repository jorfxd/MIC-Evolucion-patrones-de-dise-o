/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espol.proyectop1.excepciones;

/**
 *
 * @author eliez
 */
public class CorreoExistenteException extends Exception{
    public CorreoExistenteException(String mensaje) {
        super(mensaje);
    }
}
