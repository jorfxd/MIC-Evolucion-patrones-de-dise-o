/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.welleats;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

import javafx.scene.image.ImageView;
/**
 * FXML Controller class
 *
 * @author lacab
 */
public class ConozcamonosController implements Initializable {


    @FXML
    private ImageView iv_vegetariana;
    @FXML
    private ImageView iv_carnes;
    @FXML
    private ImageView iv_vegana;
    @FXML
    private ImageView iv_poca;
    @FXML
    private ImageView iv_moderada;
    @FXML
    private ImageView iv_intensa;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
