package com.buyerfruits.buyercombofruits;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BuyerComboFruitsApplicationTests {

    @Test
    void contextLoads() {
    }

}
