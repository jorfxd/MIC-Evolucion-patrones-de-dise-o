package com.klashz.microcomments.dto;

public record UserDto(Long id , String name, String email) {
}
