package com.klashz.microcomments;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroCommentsApplicationTests {

    @Test
    void contextLoads() {
    }

}
