package com.klashz.microproduct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroProductApplicationTests {

    @Test
    void contextLoads() {
    }

}
