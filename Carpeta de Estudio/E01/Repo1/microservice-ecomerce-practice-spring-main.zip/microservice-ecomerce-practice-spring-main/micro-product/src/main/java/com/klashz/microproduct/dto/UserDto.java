package com.klashz.microproduct.dto;

public record UserDto(Long id , String name, String email) {
}