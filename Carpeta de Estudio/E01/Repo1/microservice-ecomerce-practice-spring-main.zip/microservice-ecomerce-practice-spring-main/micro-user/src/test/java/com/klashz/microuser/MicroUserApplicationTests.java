package com.klashz.microuser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroUserApplicationTests {

    @Test
    void contextLoads() {
    }

}
