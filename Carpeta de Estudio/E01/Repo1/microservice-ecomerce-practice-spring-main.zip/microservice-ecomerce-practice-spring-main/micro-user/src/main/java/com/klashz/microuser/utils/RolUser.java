package com.klashz.microuser.utils;

public enum RolUser {
    CLIENT,ADMIN
}
