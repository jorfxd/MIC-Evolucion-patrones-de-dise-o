package com.klashz.microorder.utils;

public enum OrderStatus {
    PENDING,SHIPPED,DELIVERED,CANCELLED
}
