package com.klashz.microconfigserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroConfigServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
