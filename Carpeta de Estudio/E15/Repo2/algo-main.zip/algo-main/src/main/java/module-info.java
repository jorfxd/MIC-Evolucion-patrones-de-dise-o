module ejerc.proyecto.estructuras {
    requires javafx.controls;
    requires javafx.base;
    requires javafx.graphics;
    exports ejerc.proyecto.estructuras;
}
