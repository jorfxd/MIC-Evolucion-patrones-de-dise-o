public abstract class TileFactory {
    public abstract TetrisTile createTile(String type);
}